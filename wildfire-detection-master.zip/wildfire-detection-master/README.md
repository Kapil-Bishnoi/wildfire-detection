EARLY-WILDFIRE-DETECTION


Devloped for Nasa Space App challenge For early wildfire detection used a temp sensor for sensing environment conditions and displaying on the Oled screen.If the surrounding temperature reaches to the threshold set our system starts operating.A lame senor senses the fire conditions there and report to the headquater.The headquater than deploy drones to verify thermal images that weather it is a wildfire or human induced fire.If images are verified it alarms the officials to take actions.
